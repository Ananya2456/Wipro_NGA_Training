﻿document.addEventListener("DOMContentLoaded", () => {
    console.log("Static JS loaded successfully!");
});