﻿using Microsoft.Win32;
using Serilog;
using System;
using System.Buffers.Text;
using System.Collections.Generic;
using UserManagementApp;


//Summary of this .NET User Management Assignment Task
//1. Assignment Goal:
//Develop a secure and reliable .NET console application for user management.

//Key features include:

//User registration with password hashing (using SHA-256).

//Encryption of sensitive user details (using AES symmetric encryption).

//User authentication (password verification).

//Logging of key actions and errors (using Serilog).

//Comprehensive unit testing of core functionality.

//2. Project Setup:
//Created a new .NET console application project.

//Created a separate test project using xUnit for unit tests.

//Installed necessary NuGet packages: Serilog and Serilog.Sinks.File for logging.

//xUnit and testing related packages for unit testing.

//3.Code Implementation:
//User.cs:
//Implemented User class with :

//UserName, hashed password, and encrypted sensitive details fields.

//Methods to register (hash password and encrypt details) and authenticate (verify password).

//Password hashing done with SHA-256.

//EncryptionService.cs:

//AES - based symmetric encryption and decryption service used to secure sensitive user information.

//Program.cs:

//Interface to register new users and log them in.

//Securely handles user input (password masking included).

//Logs successful registration and login attempts, including failures.

//Implements robust error handling with proper logging.

//4. Unit Testing:
//Created UserTests.cs with tests for:

//Successful registration and authentication.

//Encryption and decryption correctness.

//Error handling that ensures no sensitive data leaks via exceptions.


namespace UserManagementApp
{
    public class Program
    {
        static void Main()
        {
            // Configure logging
            Log.Logger = new LoggerConfiguration().WriteTo.File("logs.txt").CreateLogger();

            EncryptionService encryption = new EncryptionService();
            List<User> users = new();

            try
            {
                Console.WriteLine("Register New User");
                Console.Write("Username: ");
                string username = Console.ReadLine();
                Console.Write("Password: ");
                string password = Console.ReadLine();
                Console.Write("Enter Details (sensitive): ");
                string details = Console.ReadLine();

                var user = new User(username);
                user.Register(password, details, encryption);
                users.Add(user);

                Log.Information("User {Username} registered successfully at {Time}", username, DateTime.Now);

                // Login
                Console.WriteLine("\nLogin User");
                Console.Write("Username: ");
                string loginUsername = Console.ReadLine();
                Console.Write("Password: ");
                string loginPassword = Console.ReadLine();

                var foundUser = users.FirstOrDefault(u => u.UserName == loginUsername);
                if (foundUser != null && foundUser.Authenticate(loginPassword))
                {
                    Log.Information("User {Username} logged in successfully at {Time}", loginUsername, DateTime.Now);

                    // Display sensitive info
                    string decryptedDetails = encryption.Decrypt(foundUser.EncryptedDetails);
                    Console.WriteLine($"Welcome {foundUser.UserName}! Your data: {decryptedDetails}");
                }
                else
                {
                    Log.Warning("Unsuccessful login attempt for {Username} at {Time}", loginUsername, DateTime.Now);
                    Console.WriteLine("Invalid credentials.");
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex, "An error occurred: {Message}", ex.Message);
                Console.WriteLine("An unexpected error occurred. Please contact support.");
            }
        }
    }
}