﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;

namespace DesignPatternAssignment_2
{
    public class PDFDocument : Document
    {
        public override void Print()
        {
            Console.WriteLine("PDF Document Printed");
        }
    }
}
