﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;

namespace DesignPatternAssignment_2
{
    public class DocumentFactor
    {
        public static Document Create(string type)
        {
            return type switch
            {
                "PDF" => new PDFDocument(),
                "Word" => new WordDocument(),
                _ => throw new ArgumentException("Invalid document type"),
            };
        }
    }
}
