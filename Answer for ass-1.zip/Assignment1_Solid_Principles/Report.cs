﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1_Solid_Principles
{
    // Report.cs
    public class Report
    {
        public string? Title { get; set; }
        public string? Content { get; set; }
    }

}