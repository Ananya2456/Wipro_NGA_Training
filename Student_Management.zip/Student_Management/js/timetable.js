document.addEventListener('DOMContentLoaded', function () {
  const timetableEl = document.getElementById('timetable');
  const classSelect = document.getElementById('classSelect');

  const schedules = {
    grade8: {
      Monday: [
        { time: '09:00 - 10:00', subject: 'Mathematics', teacher: 'Mr. Rao', room: '101' },
        { time: '10:00 - 11:00', subject: 'Science', teacher: 'Ms. Iyer', room: 'Lab' },
        { time: '11:30 - 12:30', subject: 'English', teacher: 'Ms. Patel', room: '102' }
      ],
      Tuesday: [
        { time: '09:00 - 10:00', subject: 'History', teacher: 'Mr. Kumar', room: '103' },
        { time: '10:00 - 11:00', subject: 'Computer', teacher: 'Ms. Dsouza', room: 'Comp Lab' },
        { time: '11:30 - 12:30', subject: 'PE', teacher: 'Coach Ajay', room: 'Ground' }
      ],
      Wednesday: [
        { time: '09:00 - 10:00', subject: 'Mathematics', teacher: 'Mr. Rao', room: '101' },
        { time: '10:00 - 11:00', subject: 'Science', teacher: 'Ms. Iyer', room: 'Lab' },
        { time: '11:30 - 12:30', subject: 'Art', teacher: 'Ms. George', room: 'Art Room' }
      ],
      Thursday: [
        { time: '09:00 - 10:00', subject: 'Geography', teacher: 'Ms. Sen', room: '104' },
        { time: '10:00 - 11:00', subject: 'Music', teacher: 'Mr. Thomas', room: 'Music Room' },
        { time: '11:30 - 12:30', subject: 'English', teacher: 'Ms. Patel', room: '102' }
      ],
      Friday: [
        { time: '09:00 - 10:00', subject: 'Mathematics', teacher: 'Mr. Rao', room: '101' },
        { time: '10:00 - 11:00', subject: 'Science', teacher: 'Ms. Iyer', room: 'Lab' },
        { time: '11:30 - 12:30', subject: 'Library', teacher: 'Librarian', room: 'Library' }
      ]
    },

    grade9: {
      Monday: [
        { time: '09:00 - 10:00', subject: 'Physics', teacher: 'Dr. Sharma', room: '201' },
        { time: '10:00 - 11:00', subject: 'Chemistry', teacher: 'Ms. Roy', room: 'Chem Lab' },
        { time: '11:30 - 12:30', subject: 'English', teacher: 'Ms. Gill', room: '202' }
      ],
      Tuesday: [
        { time: '09:00 - 10:00', subject: 'Biology', teacher: 'Mr. Singh', room: 'Bio Lab' },
        { time: '10:00 - 11:00', subject: 'Mathematics', teacher: 'Mr. Mehta', room: '203' },
        { time: '11:30 - 12:30', subject: 'History', teacher: 'Mr. Kumar', room: '204' }
      ],
      Wednesday: [
        { time: '09:00 - 10:00', subject: 'Physics', teacher: 'Dr. Sharma', room: '201' },
        { time: '10:00 - 11:00', subject: 'Chemistry', teacher: 'Ms. Roy', room: 'Chem Lab' },
        { time: '11:30 - 12:30', subject: 'Computer', teacher: 'Ms. Dsouza', room: 'Comp Lab' }
      ],
      Thursday: [
        { time: '09:00 - 10:00', subject: 'Geography', teacher: 'Ms. Sen', room: '104' },
        { time: '10:00 - 11:00', subject: 'Music', teacher: 'Mr. Thomas', room: 'Music Room' },
        { time: '11:30 - 12:30', subject: 'Biology', teacher: 'Mr. Singh', room: 'Bio Lab' }
      ],
      Friday: [
        { time: '09:00 - 10:00', subject: 'Math', teacher: 'Mr. Mehta', room: '203' },
        { time: '10:00 - 11:00', subject: 'Chemistry', teacher: 'Ms. Roy', room: 'Chem Lab' },
        { time: '11:30 - 12:30', subject: 'Library', teacher: 'Librarian', room: 'Library' }
      ]
    }
  };

  function renderSchedule(classKey) {
    timetableEl.innerHTML = ''; // clear existing
    const schedule = schedules[classKey];
    const days = ['Monday','Tuesday','Wednesday','Thursday','Friday'];

    days.forEach(day => {
      const col = document.createElement('div');
      col.className = 'col-lg-2 col-md-4 col-sm-6 mb-3'; // Bootstrap grid columns

      // Card
      const card = document.createElement('div');
      card.className = 'card h-100 shadow-sm';

      const cardHeader = document.createElement('div');
      cardHeader.className = 'card-header text-center fw-bold bg-primary text-white';
      cardHeader.textContent = day;
      card.appendChild(cardHeader);

      const cardBody = document.createElement('div');
      cardBody.className = 'card-body p-2';

      const slots = schedule[day] || [];
      if (slots.length === 0) {
        cardBody.innerHTML = '<p class="text-muted small mb-0">No classes</p>';
      } else {
        slots.forEach(slot => {
          const s = document.createElement('div');
          s.className = 'p-2 mb-2 bg-light rounded hover-shadow';
          s.style.cursor = 'pointer';
          s.innerHTML = `
            <div class="fw-semibold">${slot.subject}</div>
            <div class="text-muted small">${slot.time} | ${slot.room}</div>
          `;
          s.addEventListener('click', () => showSlotDetail(day, slot));
          cardBody.appendChild(s);
        });
      }

      card.appendChild(cardBody);
      col.appendChild(card);
      timetableEl.appendChild(col);
    });
  }

  // Modal
  const slotModal = new bootstrap.Modal(document.getElementById('slotModal'));
  const slotModalLabel = document.getElementById('slotModalLabel');
  const slotModalBody = document.getElementById('slotModalBody');

  function showSlotDetail(day, slot) {
    slotModalLabel.textContent = `${slot.subject} — ${day}`;
    slotModalBody.innerHTML = `
      <p><strong>Time:</strong> ${slot.time}</p>
      <p><strong>Teacher:</strong> ${slot.teacher}</p>
      <p><strong>Room:</strong> ${slot.room}</p>
    `;
    slotModal.show();
  }

  renderSchedule(classSelect.value);
  classSelect.addEventListener('change', () => renderSchedule(classSelect.value));
});
